package com.example.reminders

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper

class FeedReaderDbHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "Reminderlist"
        private const val DATABASE_VERSION = 1
        private const val TABLE_CONTACTS = "ReminderHistory"

        private const val KEY_ID = "_id"
        private const val KEY_ITEM = "item"
        private const val KEY_HOUR = "hour"
        private const val KEY_MIN = "minute"
        private const val KEY_DATE = "date"

        private const val SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS $DATABASE_NAME"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        //creating table
        val SQL_CREATE_TABLE =
            ("CREATE TABLE $TABLE_CONTACTS ($KEY_ID INTEGER PRIMARY KEY,$KEY_ITEM TEXT,$KEY_HOUR INT, $KEY_MIN INT, $KEY_DATE STRING)")
        if (db != null) {
            db.execSQL(SQL_CREATE_TABLE)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        db.execSQL(SQL_DELETE_ENTRIES)
        onCreate(db)
    }

    fun addReminder(rHist: reminderHistory): Long {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(KEY_ITEM, rHist.item) //reminderHistory item name
        contentValues.put(KEY_HOUR, rHist.hour) //reminderHistory item hour
        contentValues.put(KEY_MIN, rHist.min)  //reminderHistory item minute
        contentValues.put(KEY_DATE, rHist.date) //reminderHistory item daily

        //insert row
        val success = db.insert(TABLE_CONTACTS, null, contentValues)

        db.close() //close database connection
        return success
    }

    fun viewReminder(): ArrayList<reminderHistory> {
        val rHistList: ArrayList<reminderHistory> = ArrayList()
        val selectQuery = "SELECT * FROM $TABLE_CONTACTS ORDER BY $KEY_ID ASC"
        val db = this.readableDatabase
        var cursor: Cursor? = null

        try {
            cursor = db.rawQuery(selectQuery, null)
        } catch (e: SQLiteException) {
            db.execSQL(selectQuery)
            return ArrayList()
        }
        var id: Int
        var item: String
        var hour: Int
        var min: Int
        var date: String

        if (cursor.moveToFirst()) {
            do {
                id = cursor.getInt((cursor.getColumnIndex(KEY_ID)))
                item = cursor.getString(cursor.getColumnIndex(KEY_ITEM))
                hour = cursor.getInt(cursor.getColumnIndex(KEY_HOUR))
                min = cursor.getInt(cursor.getColumnIndex(KEY_MIN))
                date = cursor.getString(cursor.getColumnIndex(KEY_DATE))

                val reminder =
                    reminderHistory(id = id, item = item, hour = hour, min = min, date = date)
                rHistList.add(reminder)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return rHistList
    }

    fun deleteReminder(rHist: reminderHistory): Int {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(KEY_ID, rHist.id)
        //delete row
        val success = db.delete(TABLE_CONTACTS, KEY_ID + "=" + rHist.id, null)
        //close db connection
        db.close()
        return success
    }

    fun updateReminder(rHist: reminderHistory): Int {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(KEY_ITEM, rHist.item) //reminderHistory item name
        contentValues.put(KEY_HOUR, rHist.hour) //reminderHistory item hour
        contentValues.put(KEY_MIN, rHist.min)  //reminderHistory item minute
        contentValues.put(KEY_DATE, rHist.date) //reminderHistory item daily

        //update row
        val success = db.update(TABLE_CONTACTS, contentValues, KEY_ID + "=" + rHist.id, null)

        db.close()
        return success
    }
}
