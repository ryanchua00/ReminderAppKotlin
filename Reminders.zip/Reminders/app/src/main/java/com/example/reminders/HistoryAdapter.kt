package com.example.reminders

import android.content.Context
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.history_todo.view.*
import kotlin.collections.ArrayList

class HistoryAdapter(private val context: Context, private val items: ArrayList<reminderHistory> )
    : RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {

    class HistoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvDateSet: TextView = itemView.tvDateSet
        val tvTimeSet: TextView = itemView.tvTimeSet
        val tvReminderHistory: TextView = itemView.textView
        val ivDelete: ImageView = itemView.ivDelete
        val ivEdit: ImageView = itemView.ivEdit
        val cbDone: CheckBox = itemView.cbDone
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        return HistoryViewHolder(
            LayoutInflater.from(context).inflate(
                R.layout.history_todo,
                parent,
                false
            )
        )
    }

    /**
     * Display values in respective holders
     */
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val item = items[position]
        holder.tvReminderHistory.text = item.item
        holder.tvDateSet.text = item.date
        //holder.tvTimeSet.text = item.hour.toString() + ":" + item.min.toString()
        holder.tvTimeSet.text = context.resources.getString(R.string.tvTimeSet, item.hour, item.min)
        holder.ivEdit.setOnClickListener {
            if (context is HistoryActivity) {
                context.updateRecordAlertDialog(item)
            }
        }
        holder.ivDelete.setOnClickListener {
            if (context is HistoryActivity) {
                context.deleteRecordAlertDialog(item)
            }
        }
        holder.cbDone.setOnCheckedChangeListener { _, _ ->
            if (context is HistoryActivity) {
                context.toggleStrikeThrough(holder.tvReminderHistory, item)
            }
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }
}