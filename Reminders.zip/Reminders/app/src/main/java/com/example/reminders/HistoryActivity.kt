package com.example.reminders

import android.app.*
import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.icu.util.Calendar
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.history_main.*
import kotlinx.android.synthetic.main.history_main.etReminder
import kotlinx.android.synthetic.main.update_dialog.*

class HistoryActivity : AppCompatActivity() {

    lateinit var historyAdapter: HistoryAdapter

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.history_main)
        setupListOfDataIntoRecyclerView(this)
        historyAdapter = HistoryAdapter(this, arrayListOf())
        val addReminder : Button = findViewById(R.id.btnAddReminder)
        addReminder.setOnClickListener {

            val reminderTitle = etReminder.text.toString()
            // if entry not empty
            if(reminderTitle.isNotEmpty()) {

                // insert into SQL database
                val cal = Calendar.getInstance()
                val timePicker = TimePickerDialog.OnTimeSetListener { _, hourOfDay, minute ->
                    DatePickerDialog(
                        this,
                        {_, year, month, day ->
                        cal.set(Calendar.YEAR, year)
                        cal.set(Calendar.MONTH, month)
                        cal.set(Calendar.DAY_OF_MONTH, day)
                            val databaseHandler = FeedReaderDbHelper(this)
                            val status = databaseHandler.addReminder(
                                reminderHistory(
                                    0, reminderTitle,
                                    hourOfDay,
                                    minute,
                                    "$day/$month/$year"
                                )
                            )
                            if (status > -1) {
                                Toast.makeText(
                                    this,
                                    "Reminder added successfully",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        },
                        cal.get(Calendar.YEAR),
                        cal.get(Calendar.MONTH),
                        cal.get(Calendar.DAY_OF_MONTH)
                    ).show()
                }
                // create picker
                TimePickerDialog(this, timePicker, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
                etReminder.text.clear()
            }
        }
    }

    /**
     * Create Menu bar on top of application
     */
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    /**
     * onClick of Menu Option
     */
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId) {
            R.id.iSettings -> {
                Toast.makeText(
                    this,
                    "Use Android Settings to modify Application",
                    Toast.LENGTH_LONG
                ).show()
                true
            }
            R.id.iRefresh -> {
                finish()
                startActivity(intent)
                true
            }
            R.id.iAbout -> {
                setContentView(R.layout.about_me)
                true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    //show list of inserted data
    private fun setupListOfDataIntoRecyclerView(context: Context) {
        if (getItemsList().size > 0) {
            tvEmptyHistory.visibility = View.GONE
            rvHistory.visibility = View.VISIBLE
            rvHistory.layoutManager = LinearLayoutManager(context)
            val itemAdapter = HistoryAdapter(context, getItemsList())
            rvHistory.adapter = itemAdapter
        }
        else {
            tvEmptyHistory.visibility = View.VISIBLE
            rvHistory.visibility = View.GONE
        }
    }

    private fun getItemsList(): ArrayList<reminderHistory> {
        //create instance of DatabaseHandler
        val databaseHandler = FeedReaderDbHelper(this)
        //call method to view database
        return databaseHandler.viewReminder()
    }

    /**
     * Delete Reminder from SQLite database
     */
    fun deleteRecordAlertDialog(rHist: reminderHistory) {
        val builder = AlertDialog.Builder(this)
        // set message title
        builder.setTitle("Delete Reminder")
        builder.setMessage("Are you sure you want to delete ${rHist.item}")
        builder.setIcon(android.R.drawable.ic_delete)

        builder.setPositiveButton("Yes") { dialogInterface, _ ->
            //create instance of DatabaseHandler
            val databaseHandler = FeedReaderDbHelper(this)
            //call deleteReminder method
            val status = databaseHandler.deleteReminder(reminderHistory(rHist.id, "", 0, 0 , "0"))
            if (status > -1) {
                Toast.makeText(
                    applicationContext,
                    "Reminder deleted successfully",
                    Toast.LENGTH_LONG
                ).show()

                setupListOfDataIntoRecyclerView(this)
            }
            dialogInterface.dismiss()
        }

        builder.setNegativeButton("No") { dialogInterface, _ ->
            dialogInterface.dismiss()
        }

        val alertDialog: AlertDialog = builder.create()
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    @RequiresApi(Build.VERSION_CODES.N)
    fun updateRecordAlertDialog(rHist: reminderHistory) {
        // set screen content from layout resource
        val updateDialog = Dialog(this, R.style.theme_Dialog)

        updateDialog.setCancelable(false)
        updateDialog.setContentView(R.layout.update_dialog)
        updateDialog.etUpdateItem.setText(rHist.item)
        updateDialog.tvUpdate.setOnClickListener {

            val item =  updateDialog.etUpdateItem.text.toString()

            val cal = Calendar.getInstance()
            if (item.isNotEmpty()) {
                val timePicker = TimePickerDialog.OnTimeSetListener { _, hourOfDay, minute ->
                    DatePickerDialog(
                        this,
                        {_, year, month, day ->
                            cal.set(Calendar.YEAR, year)
                            cal.set(Calendar.MONTH, month)
                            cal.set(Calendar.DAY_OF_MONTH, day)

                            //create instance of DatabaseHandler
                            val databaseHandler = FeedReaderDbHelper(this)
                            val status = databaseHandler.updateReminder(reminderHistory(rHist.id, item, hourOfDay, minute ,"$day/$month/$year"))
                            if (status > -1) {

                                Toast.makeText(
                                    applicationContext,
                                    "Reminder updated successfully",
                                    Toast.LENGTH_LONG
                                ).show()

                                setupListOfDataIntoRecyclerView(this)

                                updateDialog.dismiss()
                            }
                        },
                        cal.get(Calendar.YEAR),
                        cal.get(Calendar.MONTH),
                        cal.get(Calendar.DAY_OF_MONTH)
                    ).show()
                }
            // create picker
            TimePickerDialog(this, timePicker, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
            } else {
                Toast.makeText(
                    applicationContext,
                    "Reminder Title cannot be blank",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        updateDialog.tvCancel.setOnClickListener {
            updateDialog.dismiss()
        }

        //start the dialog and show on screen
        updateDialog.show()
    }

    /**
     * Toggle strike and text colour of textview
     */
    fun toggleStrikeThrough (textView: TextView, rHist: reminderHistory) {
        if(!rHist.isChecked) {
            textView.paintFlags = textView.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            textView.setTextColor(Color.GRAY)
            rHist.isChecked = !rHist.isChecked
        } else if (rHist.isChecked){
            textView.paintFlags = textView.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            textView.setTextColor(Color.BLACK)
            rHist.isChecked = !rHist.isChecked
        }
    }
}
