package com.example.reminders

data class reminderHistory(
    val id: Int,
    val item: String,
    val hour: Int,
    val min: Int,
    val date: String,
    var isChecked:Boolean = false
)
